"""
Forge AI Code - AI编程助手命令行工具

模块化项目结构
"""

__version__ = "1.0.0"
__author__ = "Forge AI Team"
